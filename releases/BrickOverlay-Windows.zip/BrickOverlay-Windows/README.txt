Brick Overlay for Windows

适用于 Windows 10/11。解压整个文件夹后，双击“Start Brick Overlay.cmd”。首次启动会自动编译，可能需要几秒；之后会直接启动。无需安装 Visual Studio。请保留同目录下的 BrickOverlay.cs 和 Start.ps1。

彩色砖块透卡默认鼠标穿透。右侧“⋯”按钮打开菜单，可解锁移动、调整 Appearance、切换或保存预设。解锁后拖动透卡，锁定后恢复鼠标穿透。Appearance 中高度可调到 1000 px。

任务栏通知区域的图标始终提供“显示/隐藏透卡”和“退出”，即使透卡被隐藏也能恢复。设置与用户预设保存在 %APPDATA%\BrickOverlay\settings.xml。

此包在 macOS 上制作，未能在 Windows 上实机运行验证。若首次启动失败，请把弹出的错误内容发回来。
